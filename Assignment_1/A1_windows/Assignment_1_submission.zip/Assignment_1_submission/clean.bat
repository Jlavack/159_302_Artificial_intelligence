del *.o
del *.exe